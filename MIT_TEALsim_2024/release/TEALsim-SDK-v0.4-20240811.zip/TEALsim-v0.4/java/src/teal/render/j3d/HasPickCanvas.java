package teal.render.j3d;

import com.sun.j3d.utils.picking.PickCanvas;

public interface HasPickCanvas {
	PickCanvas getPickCanvas();
}
