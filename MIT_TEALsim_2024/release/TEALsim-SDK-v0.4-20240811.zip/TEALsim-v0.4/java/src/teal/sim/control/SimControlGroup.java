/*
 * TEALsim - MIT TEAL Project
 * Copyright (c) 2004 The Massachusetts Institute of Technology. All rights reserved.
 * Please see license.txt in top level directory for full license.
 * 
 * http://icampus.mit.edu/teal/TEALsim
 * 
 * $Id: SimControlGroup.java,v 1.5 2007/07/16 22:05:00 pbailey Exp $ 
 * 
 */

package teal.sim.control;

import java.beans.PropertyChangeEvent;

import teal.sim.TSimElement;
import teal.ui.control.ControlGroup;


/**
 * @author pbailey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SimControlGroup extends ControlGroup implements TSimElement {

    /**
     * Comment for <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = 2470029575653336474L;
    
  

    /* (non-Javadoc)
     * @see java.beans.PropertyChangeListener#propertyChange(java.beans.PropertyChangeEvent)
     */
    public void propertyChange(PropertyChangeEvent ev) {
        // TODO Auto-generated method stub

    }

}
